#ifndef MAIN_HPP
# define MAIN_HPP

#define WIDTH 1280
#define HEIGHT 720

#include "raylib.h"
#include <cmath>

#endif