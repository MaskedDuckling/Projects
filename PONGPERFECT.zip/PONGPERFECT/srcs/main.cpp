#include "Game.hpp"

int main(){
    Game game;
    game.menu();
    game.loop();
}